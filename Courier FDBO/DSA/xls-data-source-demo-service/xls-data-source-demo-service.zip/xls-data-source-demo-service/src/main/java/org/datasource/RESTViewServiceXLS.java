package org.datasource;

import java.util.List;
import java.util.logging.Logger;

import org.datasource.xlsx.categories.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


/*	REST Service URL
	http://localhost:8094/xls-data-source-demo-service/rest/customers/CustomerCategoryView
	http://localhost:8094/xls-data-source-demo-service/rest/destinatari/DestinatariView
*/
@RestController @RequestMapping("/destinatari")
public class RESTViewServiceXLS {
	private static Logger logger = Logger.getLogger(RESTViewServiceXLS.class.getName());
	
	@RequestMapping(value = "/test", method = RequestMethod.GET, 
			produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody
	public String testDataSource() {
		logger.info(">>>> REST XML Data Source is Up!");
		return "Test response from JDBCDataSource!";
	}
	
	@RequestMapping(value = "/DestinatariView", method = RequestMethod.GET,
		produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody
	public List<DestinatariView> get_DestinatariView() throws Exception {
		List<DestinatariView> viewList = this.destinatariViewBuilder.build().getDestinatariList();
		return viewList;
	}
	
//	@RequestMapping(value = "/TimePeriodView", method = RequestMethod.GET,
//			produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE})
//	@ResponseBody
//	public List<TimePeriodView> get_TimePeriodView() throws Exception {
//		List<TimePeriodView> viewList = this.timePeriodViewBuilder.build().getPeriodsList();
//		return viewList;
//	}
	
	// Set-up 
	private XLSXFileDataSourceConnector dataSourceConnector;
	
	private XLXSTupleViewBuilder destinatariTupleViewBuilder;
//	private XLXSTupleViewBuilder timePeriodTupleViewBuilder;
	
	private DestinatariViewBuilder destinatariViewBuilder;
//	private TimePeriodViewBuilder timePeriodViewBuilder;
	
	public RESTViewServiceXLS() throws Exception {
		this.dataSourceConnector = 
				new XLSXResourceFileDataSourceConnector("Destinatari.xlsx");
				//new XLSXWebDataSourceConnector("ftp://admin:macpass@localhost:7721/CustProdCateg.xlsx");
		//
		this.destinatariTupleViewBuilder = new XLXSTupleViewBuilder(this.dataSourceConnector, "DESTINATARI");
//		this.timePeriodTupleViewBuilder = new XLXSTupleViewBuilder(this.dataSourceConnector, "Periods");
		this.destinatariViewBuilder = new DestinatariViewBuilder(this.destinatariTupleViewBuilder);
//		this.timePeriodViewBuilder = new TimePeriodViewBuilder(this.timePeriodTupleViewBuilder);
	}
}


/* http://localhost:8080/xls-data-source-demo/rest/customers/test */
/* http://localhost:8080/xls-data-source-demo/rest/customers/CustomerCategoryView */