package org.datasource.xlsx.categories;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerCategoryView {
	private String categoryCode;
	private String categoryName;
	private Double lowerBound;
	private Double upperBound;
	//
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public Double getLowerBound() {
		return lowerBound;
	}
	public void setLowerBound(Double lowerBound) {
		this.lowerBound = lowerBound;
	}
	public Double getUpperBound() {
		return upperBound;
	}
	public void setUpperBound(Double upperBound) {
		this.upperBound = upperBound;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public CustomerCategoryView() {
		super();
	}
	public CustomerCategoryView(String categoryCode, String categoryName, Double lowerBound, Double upperBound) {
		super();
		this.categoryCode = categoryCode;
		this.categoryName = categoryName;
		this.lowerBound = lowerBound;
		this.upperBound = upperBound;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((categoryCode == null) ? 0 : categoryCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerCategoryView other = (CustomerCategoryView) obj;
		if (categoryCode == null) {
			if (other.categoryCode != null)
				return false;
		} else if (!categoryCode.equals(other.categoryCode))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "CustomerCategoryView [categoryCode=" + categoryCode + ", categoryName=" + categoryName + ", lowerBound="
				+ lowerBound + ", upperBound=" + upperBound + "]";
	}



}
