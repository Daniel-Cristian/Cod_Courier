package org.datasource.xlsx.categories;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CustomerCategoriesViewBuilder {
	// Data Cache
	private List<CustomerCategoryView> categoriesList;
	private List<Map<String, Object>> categoriesTupleList; // lista de tupluri
	public List<CustomerCategoryView> getCategoriesList() {
		return categoriesList;
	}
	public List<Map<String, Object>> getCategoriesTupleList() {
		return categoriesTupleList;
	}
	
	// Pre-builders
	private XLXSTupleViewBuilder tupleViewBuilder;
	public CustomerCategoriesViewBuilder(XLXSTupleViewBuilder tupleViewBuilder) {
		super();
		this.tupleViewBuilder = tupleViewBuilder;
	}
	
	// Builder Workflow
	public CustomerCategoriesViewBuilder build() throws Exception{
		return this.select().map();
	}
	
	public CustomerCategoriesViewBuilder select() throws Exception{
		this.categoriesTupleList = this.tupleViewBuilder.build().getTupleList();
		return this;
	}
	
	private CustomerCategoriesViewListAdapter viewListAdapter = new CustomerCategoriesViewListAdapter();
	public CustomerCategoriesViewBuilder map() throws Exception{
		this.categoriesList = this.viewListAdapter.map(categoriesTupleList);
		return this;
	}
}

class CustomerCategoriesViewListAdapter{
	private CustomerCategoryViewAdapter viewAdaptor = new CustomerCategoryViewAdapter();
	
	public List<CustomerCategoryView> map(List<Map<String, Object>> tupleList){
		List<CustomerCategoryView> viewList = new ArrayList<>();
		for (Map<String, Object> tuple: tupleList)
			viewList.add(this.viewAdaptor.map(tuple));
		return viewList;
	}
}

class CustomerCategoryViewAdapter{
	public CustomerCategoryView map(Map<String, Object> tuple){
		return new CustomerCategoryView(
				tuple.get("Category_code").toString(),
				tuple.get("Category_name").toString(),
				Double.valueOf(tuple.get("Lower_L").toString()),
				Double.valueOf(tuple.get("Upper_L").toString())
				);
	}
}