package org.datasource.xlsx.categories;

import java.util.Date;

public class TimePeriodView {
	private String period;
	private Date startDate;
	private Date endDate;
	//
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public TimePeriodView(String period, Date startDate, Date endDate) {
		super();
		this.period = period;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public TimePeriodView() {
		super();
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((period == null) ? 0 : period.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TimePeriodView other = (TimePeriodView) obj;
		if (period == null) {
			if (other.period != null)
				return false;
		} else if (!period.equals(other.period))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TimePeriodView [period=" + period + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	
	
}
