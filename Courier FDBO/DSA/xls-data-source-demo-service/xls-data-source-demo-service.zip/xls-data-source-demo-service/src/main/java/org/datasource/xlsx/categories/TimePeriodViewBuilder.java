package org.datasource.xlsx.categories;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class TimePeriodViewBuilder {
	// Data Cache
	private List<TimePeriodView> periodsList;
	private List<Map<String, Object>> periodsTupleList;
	public List<TimePeriodView> getPeriodsList() {
		return periodsList;
	}
	public List<Map<String, Object>> getPeriodsTupleList() {
		return periodsTupleList;
	}
	
	// Pre-builders
	private XLXSTupleViewBuilder tupleViewBuilder;
	public TimePeriodViewBuilder(XLXSTupleViewBuilder tupleViewBuilder) {
		super();
		this.tupleViewBuilder = tupleViewBuilder;
	}
	
	// Builder Workflow
	public TimePeriodViewBuilder build() throws Exception{
		return this.select().map();
	}
	
	public TimePeriodViewBuilder select() throws Exception{
		this.periodsTupleList = this.tupleViewBuilder.build().getTupleList();
		return this;
	}
	
	private PeriodsViewListAdapter viewListAdapter = new PeriodsViewListAdapter();
	public TimePeriodViewBuilder map() throws Exception{
		this.periodsList = this.viewListAdapter.map(periodsTupleList);
		return this;
	}
}

class PeriodsViewListAdapter{
	private TimePeriodViewAdapter viewAdaptor = new TimePeriodViewAdapter();
	
	public List<TimePeriodView> map(List<Map<String, Object>> tupleList){
		List<TimePeriodView> viewList = new ArrayList<>();
		for (Map<String, Object> tuple: tupleList)
			viewList.add(this.viewAdaptor.map(tuple));
		return viewList;
	}
}

class TimePeriodViewAdapter{
	public TimePeriodView map(Map<String, Object> tuple){
		System.out.println("XLS Tuple: " + tuple);
		return new TimePeriodView(
				tuple.get("Period").toString(),
				(Date) tuple.get("StartDate"),
				(Date) tuple.get("EndDate")
				);
	}
}